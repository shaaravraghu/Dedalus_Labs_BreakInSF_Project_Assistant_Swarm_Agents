# Dedalus Swarm Backend

A backend-only, hackathon-ready AI project using **Dedalus Labs SDK** to coordinate multiple intelligent swarm agents for physical technology design.

### 🚀 Features
- Multi-agent orchestration for hardware engineering
- Dedalus Labs LLM integration via `DedalusClient`
- Modular FastAPI backend
- Scalable for any engineering domain (drones, cars, etc.)

### 🧩 Setup
```bash
pip install fastapi uvicorn requests
export DEDALUS_API_KEY="your_key_here"
uvicorn app.main:app --reload
```

### 🧠 Example
```bash
curl -X POST http://127.0.0.1:8000/project/plan -H "Content-Type: application/json" -d '{"goal":"build a self-driving car"}'
```

### 🧰 Agents
- Technical & Engineering
- Design & Performance
- Team & Management
- Business & Resources
- Legal & Ethical
- Deployment & Feedback
