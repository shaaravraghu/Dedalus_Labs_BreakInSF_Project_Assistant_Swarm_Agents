import os
import requests

class DedalusClient:
    def __init__(self):
        self.api_key = os.getenv("DEDALUS_API_KEY", "demo-key")
        self.base_url = "https://api.dedaluslabs.ai/v1"

    async def query(self, prompt: str):
        payload = {"model": "dedalus-llm", "prompt": prompt}
        response = requests.post(f"{self.base_url}/query", json=payload, headers={"Authorization": f"Bearer {self.api_key}"})
        return response.json().get("output", "No response")
