from fastapi import FastAPI
from .agents import technical_agent, design_agent, team_agent, business_agent, legal_agent, deployment_agent
from .utils.dedalus_client import DedalusClient

app = FastAPI(title="Dedalus Swarm Backend")

@app.post("/project/plan")
async def generate_project_plan(user_input: dict):
    client = DedalusClient()
    query = user_input.get("goal")

    tech = await technical_agent.handle(client, query)
    design = await design_agent.handle(client, tech)
    team = await team_agent.handle(client, tech)
    business = await business_agent.handle(client, tech)
    legal = await legal_agent.handle(client, tech)
    deploy = await deployment_agent.handle(client, tech)

    final_plan = {
        "Technical": tech,
        "Design": design,
        "Team": team,
        "Business": business,
        "Legal": legal,
        "Deployment": deploy
    }
    return {"plan": final_plan}
