async def handle(client, tech_context):
    prompt = f"Given {tech_context}, list legal and regulatory constraints."
    return await client.query(prompt)
