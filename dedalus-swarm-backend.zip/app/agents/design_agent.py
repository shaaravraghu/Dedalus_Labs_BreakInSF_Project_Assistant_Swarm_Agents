async def handle(client, tech_context):
    prompt = f"Given {tech_context}, define design and performance metrics."
    return await client.query(prompt)
