async def handle(client, tech_context):
    prompt = f"Given {tech_context}, define ideal team composition and workflow tools."
    return await client.query(prompt)
