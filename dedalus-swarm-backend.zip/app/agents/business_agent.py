async def handle(client, tech_context):
    prompt = f"Given {tech_context}, estimate cost, sourcing, and funding strategy."
    return await client.query(prompt)
