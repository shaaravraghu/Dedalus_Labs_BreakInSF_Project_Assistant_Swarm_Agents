async def handle(client, goal):
    prompt = f"Define core technology stack, sensors, actuators, and control systems for {goal}."
    return await client.query(prompt)
