async def handle(client, tech_context):
    prompt = f"Given {tech_context}, describe field testing and deployment feedback loops."
    return await client.query(prompt)
